module.exports={
    empty_message:"Thuoc tinh %s khong duoc de trong",
    size_string_message: "thuoc tinh %s dai toi nhieu %d va toi da %d ki tu",
}